#/bin/sh                                                                                                                                              
                                                                                                                                                      
cd $(dirname $0)                                                                                                                                      
                                                                                                                                                      
CLASSPATH="classes:lib/commons-codec.jar:lib/j3dcore.jar:lib/j3dutils.jar:lib/javiator3d.jar:lib/jnavigator-communication.jar:lib/jnavigator-course.jar:lib/jnavigator-gps.jar:lib/jnavigator-io-java.jar:lib/jnavigator-terminal.jar:lib/jnavigator-ui.jar:lib/jnavigator-util.jar:lib/log4j.jar:lib/starfireExt.jar:lib/vecmath.jar";

java -cp $CLASSPATH -Djava.library.path=lib at.uni_salzburg.cs.ckgroup.terminal.ControlTerminal classes/ControlTerminal.properties    
